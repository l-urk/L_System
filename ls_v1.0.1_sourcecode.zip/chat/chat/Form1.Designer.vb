﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        TextBox1 = New TextBox()
        Button1 = New Button()
        TextBox2 = New TextBox()
        TextBox3 = New TextBox()
        Button2 = New Button()
        TextBox4 = New TextBox()
        TextBox5 = New TextBox()
        Button3 = New Button()
        GroupBox1 = New GroupBox()
        Label4 = New Label()
        Label1 = New Label()
        Label3 = New Label()
        TextBoxa = New TextBox()
        Button5 = New Button()
        TextBox6 = New TextBox()
        Timer1 = New Timer(components)
        Button4 = New Button()
        GroupBox2 = New GroupBox()
        Label7 = New Label()
        Label6 = New Label()
        Label5 = New Label()
        TextBox9 = New TextBox()
        TextBox8 = New TextBox()
        TextBox7 = New TextBox()
        Label2 = New Label()
        GroupBox1.SuspendLayout()
        GroupBox2.SuspendLayout()
        SuspendLayout()
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(81, 46)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(100, 23)
        TextBox1.TabIndex = 0
        TextBox1.Text = "localhost"
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(0, 46)
        Button1.Name = "Button1"
        Button1.Size = New Size(75, 24)
        Button1.TabIndex = 2
        Button1.Text = "Connect"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(187, 46)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(92, 23)
        TextBox2.TabIndex = 3
        TextBox2.Text = "11122"
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(81, 77)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(100, 23)
        TextBox3.TabIndex = 6
        TextBox3.Text = "lv"
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(12, 126)
        Button2.Name = "Button2"
        Button2.Size = New Size(75, 24)
        Button2.TabIndex = 5
        Button2.Text = "Host"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(199, 127)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(92, 23)
        TextBox4.TabIndex = 4
        TextBox4.Text = "11122"
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(297, 127)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(108, 23)
        TextBox5.TabIndex = 7
        TextBox5.Text = "chat"
        ' 
        ' Button3
        ' 
        Button3.ForeColor = SystemColors.Highlight
        Button3.Location = New Point(199, 66)
        Button3.Name = "Button3"
        Button3.Size = New Size(206, 24)
        Button3.TabIndex = 12
        Button3.Text = "Killall Netcat Proc."
        Button3.UseVisualStyleBackColor = True
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(Label4)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(TextBoxa)
        GroupBox1.Controls.Add(Button5)
        GroupBox1.Controls.Add(TextBox1)
        GroupBox1.Controls.Add(TextBox2)
        GroupBox1.Controls.Add(Button1)
        GroupBox1.Controls.Add(TextBox3)
        GroupBox1.Location = New Point(12, 50)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(393, 194)
        GroupBox1.TabIndex = 14
        GroupBox1.TabStop = False
        GroupBox1.Text = "netcat client / server"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.ForeColor = SystemColors.Highlight
        Label4.Location = New Point(6, 148)
        Label4.Name = "Label4"
        Label4.Size = New Size(385, 30)
        Label4.TabIndex = 21
        Label4.Text = "WARNING!! Not running a VPN in the background will have users know " & vbCrLf & "YOUR ip address! Please be using a VPN before using this feature!"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.ForeColor = SystemColors.Highlight
        Label1.Location = New Point(6, 133)
        Label1.Name = "Label1"
        Label1.Size = New Size(320, 15)
        Label1.TabIndex = 16
        Label1.Text = "WARNING!! Must be run as Administrator to install ncat.exe"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(6, 103)
        Label3.Name = "Label3"
        Label3.Size = New Size(264, 30)
        Label3.TabIndex = 20
        Label3.Text = "Default Format Client: ncat.exe ipaddress port" & vbCrLf & "Default Format Server: ncat.exe -lvp 11122 --chat"
        ' 
        ' TextBoxa
        ' 
        TextBoxa.Location = New Point(285, 46)
        TextBoxa.Name = "TextBoxa"
        TextBoxa.Size = New Size(108, 23)
        TextBoxa.TabIndex = 19
        TextBoxa.Text = "UserName"
        ' 
        ' Button5
        ' 
        Button5.ForeColor = SystemColors.Highlight
        Button5.Location = New Point(0, 16)
        Button5.Name = "Button5"
        Button5.Size = New Size(181, 24)
        Button5.TabIndex = 16
        Button5.Text = "Install Netcat"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(12, 12)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(393, 23)
        TextBox6.TabIndex = 15
        TextBox6.Text = "L_System"
        ' 
        ' Timer1
        ' 
        Timer1.Interval = 200
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(8, 71)
        Button4.Name = "Button4"
        Button4.Size = New Size(75, 23)
        Button4.TabIndex = 17
        Button4.Text = "DDOS"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' GroupBox2
        ' 
        GroupBox2.Controls.Add(Label7)
        GroupBox2.Controls.Add(Label6)
        GroupBox2.Controls.Add(Label5)
        GroupBox2.Controls.Add(TextBox9)
        GroupBox2.Controls.Add(TextBox8)
        GroupBox2.Controls.Add(TextBox7)
        GroupBox2.Controls.Add(Label2)
        GroupBox2.Controls.Add(Button4)
        GroupBox2.Location = New Point(12, 250)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(393, 100)
        GroupBox2.TabIndex = 18
        GroupBox2.TabStop = False
        GroupBox2.Text = "ddos with hammer"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.ForeColor = SystemColors.Highlight
        Label7.Location = New Point(285, 54)
        Label7.Name = "Label7"
        Label7.Size = New Size(79, 15)
        Label7.TabIndex = 23
        Label7.Text = "turbo  (1-999)"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.ForeColor = SystemColors.Highlight
        Label6.Location = New Point(187, 54)
        Label6.Name = "Label6"
        Label6.Size = New Size(29, 15)
        Label6.TabIndex = 22
        Label6.Text = "port"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.ForeColor = SystemColors.Highlight
        Label5.Location = New Point(89, 54)
        Label5.Name = "Label5"
        Label5.Size = New Size(48, 15)
        Label5.TabIndex = 21
        Label5.Text = "flood ip"
        ' 
        ' TextBox9
        ' 
        TextBox9.Location = New Point(285, 72)
        TextBox9.Name = "TextBox9"
        TextBox9.Size = New Size(102, 23)
        TextBox9.TabIndex = 20
        TextBox9.Text = "135"
        ' 
        ' TextBox8
        ' 
        TextBox8.Location = New Point(187, 72)
        TextBox8.Name = "TextBox8"
        TextBox8.Size = New Size(92, 23)
        TextBox8.TabIndex = 20
        TextBox8.Text = "80"
        ' 
        ' TextBox7
        ' 
        TextBox7.Location = New Point(89, 72)
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(92, 23)
        TextBox7.TabIndex = 19
        TextBox7.Text = "localhost"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.ForeColor = SystemColors.Highlight
        Label2.Location = New Point(6, 19)
        Label2.Name = "Label2"
        Label2.Size = New Size(173, 15)
        Label2.TabIndex = 19
        Label2.Text = "Python must be installed to use"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1284, 761)
        Controls.Add(GroupBox2)
        Controls.Add(TextBox6)
        Controls.Add(Button3)
        Controls.Add(TextBox5)
        Controls.Add(Button2)
        Controls.Add(TextBox4)
        Controls.Add(GroupBox1)
        Name = "Form1"
        Text = "Form1"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Button5 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBoxa As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
End Class
