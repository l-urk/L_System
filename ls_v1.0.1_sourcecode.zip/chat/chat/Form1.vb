﻿Imports System.Diagnostics.Eventing.Reader
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
        Timer1.Start()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim desktopPath As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
        Dim process As New Process()
        process.StartInfo.FileName = desktopPath & "\L_System\nc\ncat.exe"
        process.StartInfo.Arguments = "-s" & TextBoxa.Text & TextBox1.Text & " " & TextBox2.Text ' Concatenate the two strings with a space in between
        process.Start()
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim desktopPath As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
        Dim process As New Process()
        process.StartInfo.FileName = desktopPath & "\L_System\nc\ncat.exe"
        process.StartInfo.Arguments = "-" & TextBox3.Text & "p" & TextBox4.Text & " --" & TextBox5.Text ' Concatenate the two strings with a space in between
        process.Start()
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim desktopPath As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
        Dim process As New Process()
        process.StartInfo.FileName = desktopPath & "\L_System\nc\taskkill_ncat.bat"
        process.Start()
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Static index As Integer = 0 'index to keep track of the current character to display
        Dim text As String = " L_System opsec tool version 1.0.1      " 'the text to animate
        If index >= text.Length Then 'reset index if it exceeds the length of the text
            index = 0
        End If
        TextBox6.Text = text.Substring(0, index + 1) 'display the text up to the current character
        index += 1 'increment the index for the next tick
    End Sub
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Process.Start("C:\Users\shera\OneDrive\Desktop\L_System\ddos\hammer\start_hammer.bat", "-s " & TextBox7.Text & " -p " & TextBox8.Text & " -t " & TextBox9.Text)
    End Sub
End Class